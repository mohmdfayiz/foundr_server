## foundr_server
> server side of foundr
<li> TypeScript </li>
